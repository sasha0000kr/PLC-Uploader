print ("Сложение чисел:")

a = int (input (""))
print ("+")
b = int (input (""))
c = a + b
print ("=")
print (c)