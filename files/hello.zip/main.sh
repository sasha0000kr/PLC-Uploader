#!/data/data/com.termux/files/usr/bin
python hello.py